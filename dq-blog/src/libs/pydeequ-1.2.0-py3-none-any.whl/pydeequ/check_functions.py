def is_one(x):
    return x == 1 / 1
